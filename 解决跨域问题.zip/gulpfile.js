const gulp = require("gulp");
const sass = require("gulp-sass");
const mincss = require("gulp-clean-css");
const babel = require("gulp-babel");
const uglify = require("gulp-uglify");
const htmlmin = require("gulp-htmlmin");
const concat = require("gulp-concat");
const webserver = require("gulp-webserver");
const fs = require("fs");
const url = require("url");
const querystring = require("querystring");
let userData = require("./data/user")

//sass编译 压缩 到dist目录
gulp.task("sass", () => {
    return gulp.src("./src/scss/*.scss")
        .pipe(sass())
        .pipe(gulp.dest("./src/css"))//拷贝到src/css
        .pipe(mincss())
        .pipe(gulp.dest("./dist/css"))
})
//js编译 压缩 到dist目录
gulp.task("js", () => {
    return gulp.src("./src/js/*.js")
        .pipe(babel({
            presets: ["env"]
        }))
        .pipe(uglify())
        .pipe(gulp.dest("./dist/js"))
})
//html 压缩 到dist目录
gulp.task("html", () => {
    return gulp.src("./src/*.html")
        .pipe(htmlmin({
            collapseWhitespace: true
        }))
        .pipe(gulp.dest("./dist"))
})
//监听 html css js的变化 实时更新
gulp.task("watch", () => {
    gulp.watch("./src/scss/*.scss", gulp.series("sass"))
    gulp.watch("./src/js/*.js", gulp.series("js"))
    gulp.watch("./src/*.html", gulp.series("html"))
})
// 加载静态资源
gulp.task("server", () => {
    return gulp.src("./dist") //读取的是dist目录下的内容
        .pipe(webserver({
            port: 8080, //端口号
            livereload: true, //热替换
            proxies: [ //反向代理 服务器代理
                { source: "/get", target: "http://localhost:3000/get" },
                { source: "/post", target: "http://localhost:3000/post" }
            ]
        }))
})
//加载接口
gulp.task("serverD", () => {
    return gulp.src(".")
        .pipe(webserver({
            port: 3000, //端口号3000
            middleware: (req, res, next) => {
                let { pathname, query } = url.parse(req.url, true)
                // 拦截get请求
                if (pathname === "/get/") {
                    //get怎么请求？url地址传参  ？  query
                    //post怎么请求？send传参  ？  流
                    // 挂载到req.query
                    req.query = query;
                    console.log(req.query)
                    let flag = userData.some(item => item.user == query.user && item.pwd == query.pwd);
                    if (flag) { //存在
                        res.end(JSON.stringify({ code: 0, msg: "登录成功" }))
                    } else {
                        res.end(JSON.stringify({ code: 1, msg: "登录失败" }))
                    }


                }
                // 拦截get请求
                if (pathname === "/post/") {//数据量大
                    let data = ``;
                    req.on("data", chuck => {
                        data += chuck;
                    })
                    req.on("end", () => {
                        // 挂载到req.body
                        data = querystring.parse(data)
                        req.body = data; //前端传递到用户名 密码
                        console.log(req.body)
                        let flag = userData.some(item => item.user == data.user);
                        if (flag) { //用户已经存在
                            res.end(JSON.stringify({ code: 1, msg: "注册失败 此用户已经存在" }))
                        } else {
                            userData.push(data)
                            fs.writeFileSync("./data/user.json", JSON.stringify(userData))
                            res.end(JSON.stringify({ code: 0, msg: "注册成功" }))
                        }
                    })

                }
            }
        }))
})
//合并任务
gulp.task("default", gulp.parallel("watch", "server", "serverD"))