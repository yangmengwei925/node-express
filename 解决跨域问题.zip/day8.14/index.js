/**
 * Created by RYPY on 2019/8/14.
 */
const http =require('http');
const querystring = require('querystring');
const fd =require('./filedb/filedb');




http.createServer((req,res)=>{
    //解决跨域问题
    res.setHeader("Access-Control-Allow-Origin", "*");
    // res.setHeader("Access-Control-Allow-Headers", "X-Requested-With");
    // res.setHeader("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
    // res.setHeader("X-Powered-By",' 3.2.1');
    // res.setHeader("Content-Type", "application/json;charset=utf-8");

    if(req.url !== '/favicon.ico'){
        let data='';
        req.on("data",(inputdata)=>{
            if(req.url==="/resguest"){
                 data=JSON.parse(querystring.unescape(inputdata));
            }else {
                data =querystring.parse(querystring.unescape(inputdata));
            }
        });
        req.on("end",()=>{
            res.writeHead("200","",{"content-type":"text/html;charset=utf-8"});
            const  newfd = new fd.filedbb();
            let userdata =JSON.parse(newfd.readfile());
            if(req.url==="/resguest"){
                let flag =false;
                for(let item of userdata){
                    if(data.username===item.username){
                        flag=true;
                    }
                }
                if(flag){
                    res.write("用户名已存在！");
                }else{
                    let newdata={"username":data.username,"pwd":data.pwd,"isadmin":"0"};
                    userdata.push(newdata)
                    newfd.writefile(userdata);
                    res.write("success");
                }
            }else{
                let flag = false;
                for(let item of userdata){
                    if(data.username===item.username&&data.pwd===item.pwd){
                        flag=true;
                    }
                }
                if(flag){
                    res.write("登录成功！");
                }
                else{
                    res.write("登录失败！");
                }            }
            res.end();
        });
    }
}).listen(8080);