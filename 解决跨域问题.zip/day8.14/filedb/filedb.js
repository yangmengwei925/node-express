/**
 * Created by RYPY on 2019/8/14.
 */
const fs = require('fs');
class filedb{
    constructor(){
    }
    readfile(pathurl){
        // let jsondata=[];
        // try {
        //     jsondata = fs.readFileSync("./json/user.json","utf-8")
        // }catch (erro) {
        //     console.log("读取文件错误"+erro);
        // }
        // return jsondata;
        return fs.readFileSync("./json/user.json","utf-8",(erro,data)=>{
           if(erro){
               console.log(erro);
               throw erro;
               return null;
           }
           else{
               return data;
           }
        });
    }
    writefile(inputjsondata){
        try {
            fs.writeFileSync("./json/user.json",JSON.stringify(inputjsondata));
        }catch (erro) {
            console.log("写文件出错"+erro);
        }finally {
            console.log("写文件结束！");
        }
    }
}
exports.filedbb=filedb;
// exports={
//     filedb:filedb
// }