const express = require("express");
const path = require("path");
const fs = require("fs");
const router = express.Router();
let userData = require("../data/user")
//渲染首页
router.get("/getUser", (req, res) => {
    res.send(userData)
})
//返回添加页面
router.get("/add", (req, res) => {
    res.render("add")
    // res.sendFile(path.join(__dirname,"../public/add.html"))
})

//增加接口 /addUser
router.post("/addUser", (req, res) => {
    let data = req.body;
    data.id = new Date() * 1 + Math.random();
    let flag = userData.some(item => item.tel == data.tel);
    if (flag) { //手机号已经存在
        res.send({ code: 1, msg: "添加失败 此用户以存在" })
    } else {
        userData.push(data);
        write(userData)
        res.send({ code: 0, msg: "添加成功" })
    }
})

//修改接口 获取默认数据接口’  update
router.get("/update", (req, res) => {
    let {id} =req.query;
    let newData = userData.filter(item=>{
        if(item.id==id){
            return item;
        }
    })
    res.send(newData)
})

//修改接口  updateUser
router.post("/updateUser", (req, res) => {
    let data = req.body;
    let newData = userData.map(item=>{
        if(data.id==item.id){
            return data;
        }
        return item;
    })
    write(newData)
    res.send({code:0,msg:"修改成功"})
   
})

//删除接口
router.get("/delUser", (req, res) => {
    let {id} =req.query;
    let newData = userData.filter(item=>{
        if(item.id!=id){
            return item;
        }
    })
    write(newData)
    res.send({code:0,msg:"删除成功"})
})

function write(data) {
    fs.writeFileSync("./data/user.json", JSON.stringify(data));
}





module.exports = router;