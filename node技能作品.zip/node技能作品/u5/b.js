let a = require('./a.js');
let arr = [2, 1, 4, 3, 5, 7, 6];
console.log(a.px(arr));