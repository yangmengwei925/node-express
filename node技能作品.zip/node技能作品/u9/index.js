let px = require("px");
console.log(px.bzpx([0, 2, 1, 5, 4]));
console.log(px.mppx([2, 0, 1, 5, 3]));