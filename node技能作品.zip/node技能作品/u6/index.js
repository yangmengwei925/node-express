let countNum = require("countNum");
let str = 'aaddddaaaff';
console.log(countNum('a', str));
console.log(countNum('b', str));
console.log(countNum('d', str));